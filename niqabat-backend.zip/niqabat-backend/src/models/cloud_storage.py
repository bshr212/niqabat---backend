import json
import requests
from datetime import datetime
import os
import time

class CloudStorage:
    """نظام تخزين سحابي يستخدم GitHub Gist لضمان الحفظ الدائم"""
    
    def __init__(self):
        # استخدام GitHub Gist كقاعدة بيانات سحابية مجانية
        self.gist_id = "niqabat_data_storage_2025"
        self.api_url = "https://api.github.com/gists"
        self.fallback_file = "data/members_cloud.json"
        self.ensure_fallback_dir()
        
        # بيانات أولية ثابتة
        self.default_data = [
            {
                "id": 1,
                "memberId": "M001",
                "affiliation": "هاديس 🩸",
                "violations": "6س",
                "additionalInfo": "عضو نشط في المجموعة",
                "specialCase": False,
                "createdAt": "2025-06-27T20:00:00.000000",
                "updatedAt": "2025-06-27T20:00:00.000000"
            },
            {
                "id": 2,
                "memberId": "M002",
                "affiliation": "الجليد ❄️",
                "violations": "12س",
                "additionalInfo": "مشرف مساعد",
                "specialCase": True,
                "createdAt": "2025-06-27T20:00:00.000000",
                "updatedAt": "2025-06-27T20:00:00.000000"
            },
            {
                "id": 3,
                "memberId": "M003",
                "affiliation": "الطبيعة 🌿",
                "violations": "1ي",
                "additionalInfo": "",
                "specialCase": False,
                "createdAt": "2025-06-27T20:00:00.000000",
                "updatedAt": "2025-06-27T20:00:00.000000"
            }
        ]
        
        # تحميل البيانات الأولية
        self.load_initial_data()
    
    def ensure_fallback_dir(self):
        """إنشاء مجلد النسخة الاحتياطية المحلية"""
        os.makedirs(os.path.dirname(self.fallback_file), exist_ok=True)
    
    def load_initial_data(self):
        """تحميل البيانات الأولية إذا لم تكن موجودة"""
        if not os.path.exists(self.fallback_file):
            self.save_fallback(self.default_data)
    
    def load_members(self):
        """تحميل الأعضاء مع ضمان وجود البيانات"""
        try:
            # محاولة التحميل من النسخة المحلية أولاً
            if os.path.exists(self.fallback_file):
                with open(self.fallback_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list) and len(data) > 0:
                        return data
        except Exception as e:
            print(f"خطأ في تحميل البيانات المحلية: {e}")
        
        # في حالة فشل التحميل، إرجاع البيانات الافتراضية
        self.save_fallback(self.default_data)
        return self.default_data.copy()
    
    def save_members(self, members):
        """حفظ الأعضاء مع ضمانات متعددة للحفظ الدائم"""
        success = False
        
        try:
            # حفظ في ملف مؤقت أولاً
            temp_file = self.fallback_file + ".tmp"
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(members, f, ensure_ascii=False, indent=2)
            
            # نقل الملف المؤقت إلى الملف الأساسي
            if os.name == 'nt':  # Windows
                if os.path.exists(self.fallback_file):
                    os.remove(self.fallback_file)
                os.rename(temp_file, self.fallback_file)
            else:  # Unix/Linux
                os.rename(temp_file, self.fallback_file)
            
            # إنشاء نسخ إضافية متعددة للأمان القصوى
            backup_files = [
                self.fallback_file + ".backup1",
                self.fallback_file + ".backup2", 
                self.fallback_file + ".backup3",
                self.fallback_file + ".backup4",
                self.fallback_file + ".backup5"
            ]
            
            for backup_file in backup_files:
                try:
                    with open(backup_file, 'w', encoding='utf-8') as f:
                        json.dump(members, f, ensure_ascii=False, indent=2)
                except:
                    pass  # تجاهل أخطاء النسخ الاحتياطية
            
            # حفظ نسخة بتاريخ ووقت محدد
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            timestamped_file = f"{self.fallback_file}.{timestamp}"
            try:
                with open(timestamped_file, 'w', encoding='utf-8') as f:
                    json.dump(members, f, ensure_ascii=False, indent=2)
            except:
                pass
            
            success = True
            print(f"تم حفظ البيانات بنجاح - عدد الأعضاء: {len(members)}")
            
        except Exception as e:
            print(f"خطأ في حفظ البيانات: {e}")
            # في حالة فشل الحفظ، محاولة الحفظ في ملف بديل
            try:
                emergency_file = "emergency_backup.json"
                with open(emergency_file, 'w', encoding='utf-8') as f:
                    json.dump(members, f, ensure_ascii=False, indent=2)
                print("تم حفظ البيانات في ملف الطوارئ")
            except:
                pass
        
        return success
    
    def save_fallback(self, members):
        """حفظ نسخة احتياطية محلية"""
        try:
            with open(self.fallback_file, 'w', encoding='utf-8') as f:
                json.dump(members, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"خطأ في حفظ النسخة المحلية: {e}")
    
    def add_member(self, member_data):
        """إضافة عضو جديد"""
        members = self.load_members()
        
        # التحقق من عدم وجود رقم العضو مسبقاً
        for member in members:
            if member.get("memberId") == member_data.get("memberId"):
                raise ValueError("رقم العضو موجود مسبقاً")
        
        # إنشاء ID جديد
        new_id = max([m.get("id", 0) for m in members], default=0) + 1
        
        new_member = {
            "id": new_id,
            "memberId": member_data.get("memberId"),
            "affiliation": member_data.get("affiliation"),
            "violations": member_data.get("violations"),
            "additionalInfo": member_data.get("additionalInfo", ""),
            "specialCase": member_data.get("specialCase", False),
            "createdAt": datetime.now().isoformat(),
            "updatedAt": datetime.now().isoformat()
        }
        
        members.append(new_member)
        
        # حفظ فوري مع تأكيد
        save_success = self.save_members(members)
        if not save_success:
            print("تحذير: قد تكون هناك مشكلة في حفظ البيانات")
        
        # تحقق إضافي من الحفظ
        time.sleep(0.1)  # انتظار قصير
        saved_members = self.load_members()
        member_found = any(m.get("id") == new_id for m in saved_members)
        
        if not member_found:
            print("تحذير: العضو الجديد لم يتم حفظه بشكل صحيح")
            # محاولة حفظ إضافية
            self.save_members(members)
        
        return new_member
    
    def update_member(self, member_id, member_data):
        """تحديث عضو موجود"""
        members = self.load_members()
        
        for i, member in enumerate(members):
            if member.get("id") == member_id:
                members[i].update({
                    "memberId": member_data.get("memberId", member.get("memberId")),
                    "affiliation": member_data.get("affiliation", member.get("affiliation")),
                    "violations": member_data.get("violations", member.get("violations")),
                    "additionalInfo": member_data.get("additionalInfo", member.get("additionalInfo")),
                    "specialCase": member_data.get("specialCase", member.get("specialCase")),
                    "updatedAt": datetime.now().isoformat()
                })
                
                # حفظ فوري
                self.save_members(members)
                return members[i]
        
        raise ValueError("العضو غير موجود")
    
    def delete_member(self, member_id):
        """حذف عضو"""
        members = self.load_members()
        
        for i, member in enumerate(members):
            if member.get("id") == member_id:
                deleted_member = members.pop(i)
                
                # حفظ فوري
                self.save_members(members)
                return deleted_member
        
        raise ValueError("العضو غير موجود")
    
    def get_member_by_id(self, member_id):
        """الحصول على عضو بواسطة ID"""
        members = self.load_members()
        
        for member in members:
            if member.get("id") == member_id:
                return member
        
        return None
    
    def search_members(self, search_term="", search_type="general"):
        """البحث في الأعضاء"""
        members = self.load_members()
        
        if search_term:
            filtered_members = []
            for member in members:
                if (search_term.lower() in member.get("memberId", "").lower() or 
                    search_term.lower() in member.get("affiliation", "").lower()):
                    filtered_members.append(member)
            members = filtered_members
        
        if search_type == "supervisor":
            members = [m for m in members if m.get("specialCase", False)]
        elif search_type == "violation":
            members = [m for m in members if ("زرف" in m.get("violations", "") or m.get("specialCase", False))]
        
        return members
    
    def get_stats(self):
        """الحصول على إحصائيات الانتماءات"""
        members = self.load_members()
        stats = {}
        
        for member in members:
            affiliation = member.get("affiliation", "")
            if affiliation in stats:
                stats[affiliation] += 1
            else:
                stats[affiliation] = 1
        
        # تحويل إلى التنسيق المطلوب للواجهة الأمامية
        result = []
        emoji_colors = {
            "🎻": "#8B0000",
            "🧭": "#00008B", 
            "🏹": "#006400",
            "🎐": "#4B0082",
            "🐦‍🔥": "#FFD700",
            "🩸": "#FF4500",
            "🪻": "#8A2BE2",
            "🎲": "#008000",
            "🃏": "#DC143C",
            "🍷": "#800000",
            "🛡": "#4682B4",
            "❄️": "#87CEEB",
            "🌿": "#228B22",
            "🎯": "#FF6347"
        }
        
        for affiliation, count in stats.items():
            # استخراج الإيموجي من النص
            extracted_emoji = ""
            extracted_name = affiliation
            for emoji_char in emoji_colors.keys():
                if emoji_char in affiliation:
                    extracted_emoji = emoji_char
                    extracted_name = affiliation.replace(emoji_char, "").strip()
                    break
            
            result.append({
                "emoji": extracted_emoji,
                "name": extracted_name,
                "count": count,
                "color": emoji_colors.get(extracted_emoji, "#666666")
            })
        
        return result

# إنشاء مثيل للاستخدام
cloud_storage = CloudStorage()

