import json
import requests
from datetime import datetime
import time

class FirebaseStorage:
    def __init__(self):
        # استخدام Firebase Realtime Database مجاني
        self.firebase_url = "https://niqabat-db-default-rtdb.firebaseio.com"
        self.members_path = "/members.json"
        self.backup_path = "/backups.json"
        
        # بيانات افتراضية
        self.default_data = [
            {
                "id": 1,
                "memberId": "M001",
                "affiliation": "الطبيعة 🌿",
                "violations": "لا يوجد",
                "additionalInfo": "عضو مؤسس",
                "specialCase": False
            },
            {
                "id": 2,
                "memberId": "M002",
                "affiliation": "الجليد ❄️",
                "violations": "لا يوجد",
                "additionalInfo": "مشرف",
                "specialCase": True
            },
            {
                "id": 3,
                "memberId": "M003",
                "affiliation": "هاديس 🩸",
                "violations": "لا يوجد",
                "additionalInfo": "عضو نشط",
                "specialCase": False
            }
        ]

    def save_members(self, members_data):
        """حفظ بيانات الأعضاء في Firebase"""
        try:
            # إنشاء نسخة احتياطية أولاً
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_data = {
                "timestamp": timestamp,
                "data": members_data,
                "count": len(members_data)
            }
            
            # حفظ النسخة الاحتياطية
            backup_url = f"{self.firebase_url}/backups/{timestamp}.json"
            backup_response = requests.put(backup_url, json=backup_data, timeout=10)
            
            # حفظ البيانات الأساسية
            main_url = f"{self.firebase_url}{self.members_path}"
            main_response = requests.put(main_url, json=members_data, timeout=10)
            
            if main_response.status_code == 200:
                print(f"تم حفظ {len(members_data)} عضو بنجاح في Firebase")
                return True
            else:
                print(f"خطأ في حفظ البيانات: {main_response.status_code}")
                return False
                
        except Exception as e:
            print(f"خطأ في الاتصال بـ Firebase: {e}")
            return False

    def load_members(self):
        """تحميل بيانات الأعضاء من Firebase"""
        try:
            url = f"{self.firebase_url}{self.members_path}"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data and isinstance(data, list):
                    print(f"تم تحميل {len(data)} عضو من Firebase")
                    return data
                else:
                    print("لا توجد بيانات في Firebase، استخدام البيانات الافتراضية")
                    self.save_members(self.default_data)
                    return self.default_data
            else:
                print(f"خطأ في تحميل البيانات: {response.status_code}")
                return self.default_data
                
        except Exception as e:
            print(f"خطأ في الاتصال بـ Firebase: {e}")
            return self.default_data

    def add_member(self, member_data):
        """إضافة عضو جديد"""
        try:
            current_members = self.load_members()
            
            # تحديد ID جديد
            max_id = max([m.get('id', 0) for m in current_members]) if current_members else 0
            member_data['id'] = max_id + 1
            
            # إضافة العضو الجديد
            current_members.append(member_data)
            
            # حفظ البيانات المحدثة
            success = self.save_members(current_members)
            
            if success:
                print(f"تم إضافة العضو {member_data.get('memberId', 'غير محدد')} بنجاح")
                return True
            else:
                print("فشل في إضافة العضو")
                return False
                
        except Exception as e:
            print(f"خطأ في إضافة العضو: {e}")
            return False

    def update_member(self, member_id, updated_data):
        """تحديث بيانات عضو"""
        try:
            current_members = self.load_members()
            
            # البحث عن العضو وتحديثه
            for i, member in enumerate(current_members):
                if member.get('id') == member_id:
                    current_members[i].update(updated_data)
                    success = self.save_members(current_members)
                    
                    if success:
                        print(f"تم تحديث العضو {member_id} بنجاح")
                        return True
                    else:
                        print("فشل في تحديث العضو")
                        return False
            
            print(f"لم يتم العثور على العضو {member_id}")
            return False
            
        except Exception as e:
            print(f"خطأ في تحديث العضو: {e}")
            return False

    def delete_member(self, member_id):
        """حذف عضو"""
        try:
            current_members = self.load_members()
            
            # البحث عن العضو وحذفه
            original_count = len(current_members)
            current_members = [m for m in current_members if m.get('id') != member_id]
            
            if len(current_members) < original_count:
                success = self.save_members(current_members)
                
                if success:
                    print(f"تم حذف العضو {member_id} بنجاح")
                    return True
                else:
                    print("فشل في حذف العضو")
                    return False
            else:
                print(f"لم يتم العثور على العضو {member_id}")
                return False
                
        except Exception as e:
            print(f"خطأ في حذف العضو: {e}")
            return False

    def get_stats(self):
        """الحصول على إحصائيات الأعضاء"""
        try:
            members = self.load_members()
            
            # حساب الإحصائيات
            total_members = len(members)
            special_cases = len([m for m in members if m.get('specialCase', False)])
            
            # حساب الانتماءات
            affiliations = {}
            for member in members:
                affiliation = member.get('affiliation', 'غير محدد')
                affiliations[affiliation] = affiliations.get(affiliation, 0) + 1
            
            return {
                "total_members": total_members,
                "special_cases": special_cases,
                "affiliations": affiliations,
                "last_updated": datetime.now().isoformat()
            }
            
        except Exception as e:
            print(f"خطأ في حساب الإحصائيات: {e}")
            return {
                "total_members": 0,
                "special_cases": 0,
                "affiliations": {},
                "last_updated": datetime.now().isoformat()
            }

    def force_backup(self):
        """إنشاء نسخة احتياطية قسرية"""
        try:
            members = self.load_members()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            backup_data = {
                "timestamp": timestamp,
                "data": members,
                "count": len(members),
                "type": "manual_backup"
            }
            
            backup_url = f"{self.firebase_url}/manual_backups/{timestamp}.json"
            response = requests.put(backup_url, json=backup_data, timeout=10)
            
            if response.status_code == 200:
                print(f"تم إنشاء نسخة احتياطية يدوية: {timestamp}")
                return True, timestamp
            else:
                print(f"فشل في إنشاء النسخة الاحتياطية: {response.status_code}")
                return False, None
                
        except Exception as e:
            print(f"خطأ في إنشاء النسخة الاحتياطية: {e}")
            return False, None

# إنشاء مثيل عام للاستخدام
firebase_storage = FirebaseStorage()

