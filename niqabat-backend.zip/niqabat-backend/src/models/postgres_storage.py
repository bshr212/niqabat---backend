import psycopg2
import psycopg2.extras
import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

class PostgreSQLStorage:
    def __init__(self):
        # استخدام متغير البيئة لرابط قاعدة البيانات
        self.database_url = os.getenv('DATABASE_URL', 'postgresql://localhost/niqabat_db')
        self.init_database()
    
    def get_connection(self):
        """إنشاء اتصال بقاعدة البيانات"""
        try:
            conn = psycopg2.connect(self.database_url)
            return conn
        except Exception as e:
            print(f"خطأ في الاتصال بقاعدة البيانات: {e}")
            return None
    
    def init_database(self):
        """إنشاء الجداول المطلوبة"""
        try:
            conn = self.get_connection()
            if not conn:
                return False
            
            cursor = conn.cursor()
            
            # إنشاء جدول الأعضاء
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS members (
                    id SERIAL PRIMARY KEY,
                    member_id VARCHAR(50) UNIQUE NOT NULL,
                    affiliation VARCHAR(200) NOT NULL,
                    violations TEXT DEFAULT 'لا يوجد',
                    additional_info TEXT DEFAULT '',
                    special_case BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # إنشاء جدول النسخ الاحتياطية
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS backups (
                    id SERIAL PRIMARY KEY,
                    backup_data JSONB NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    backup_type VARCHAR(50) DEFAULT 'auto'
                )
            """)
            
            conn.commit()
            cursor.close()
            conn.close()
            
            # إضافة بيانات أولية إذا كانت قاعدة البيانات فارغة
            self.add_initial_data()
            
            return True
            
        except Exception as e:
            print(f"خطأ في إنشاء قاعدة البيانات: {e}")
            return False
    
    def add_initial_data(self):
        """إضافة بيانات أولية إذا كانت قاعدة البيانات فارغة"""
        try:
            if self.get_members_count() == 0:
                initial_members = [
                    {
                        "member_id": "M001",
                        "affiliation": "هاديس 🩸",
                        "violations": "لا يوجد",
                        "additional_info": "عضو مؤسس",
                        "special_case": True
                    },
                    {
                        "member_id": "M002", 
                        "affiliation": "الطبيعة 🌿",
                        "violations": "لا يوجد",
                        "additional_info": "عضو نشط",
                        "special_case": False
                    },
                    {
                        "member_id": "M003",
                        "affiliation": "الجليد ❄️",
                        "violations": "لا يوجد", 
                        "additional_info": "عضو جديد",
                        "special_case": False
                    }
                ]
                
                for member in initial_members:
                    self.add_member(member)
                    
        except Exception as e:
            print(f"خطأ في إضافة البيانات الأولية: {e}")
    
    def add_member(self, member_data: Dict[str, Any]) -> bool:
        """إضافة عضو جديد"""
        try:
            conn = self.get_connection()
            if not conn:
                return False
            
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO members (member_id, affiliation, violations, additional_info, special_case)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (member_id) DO UPDATE SET
                    affiliation = EXCLUDED.affiliation,
                    violations = EXCLUDED.violations,
                    additional_info = EXCLUDED.additional_info,
                    special_case = EXCLUDED.special_case,
                    updated_at = CURRENT_TIMESTAMP
            """, (
                member_data.get("member_id"),
                member_data.get("affiliation"),
                member_data.get("violations", "لا يوجد"),
                member_data.get("additional_info", ""),
                member_data.get("special_case", False)
            ))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            # إنشاء نسخة احتياطية تلقائية
            self.create_backup("auto_after_add")
            
            return True
            
        except Exception as e:
            print(f"خطأ في إضافة العضو: {e}")
            return False
    
    def load_members(self) -> List[Dict[str, Any]]:
        """تحميل جميع الأعضاء"""
        try:
            conn = self.get_connection()
            if not conn:
                return []
            
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            cursor.execute("""
                SELECT member_id, affiliation, violations, additional_info, special_case,
                       created_at, updated_at
                FROM members
                ORDER BY created_at DESC
            """)
            
            rows = cursor.fetchall()
            cursor.close()
            conn.close()
            
            # تحويل النتائج إلى قائمة من القواميس
            members = []
            for row in rows:
                member = {
                    "memberId": row["member_id"],
                    "affiliation": row["affiliation"],
                    "violations": row["violations"],
                    "additionalInfo": row["additional_info"],
                    "specialCase": row["special_case"],
                    "createdAt": row["created_at"].isoformat() if row["created_at"] else None,
                    "updatedAt": row["updated_at"].isoformat() if row["updated_at"] else None
                }
                members.append(member)
            
            return members
            
        except Exception as e:
            print(f"خطأ في تحميل الأعضاء: {e}")
            return []
    
    def update_member(self, member_id: str, update_data: Dict[str, Any]) -> bool:
        """تحديث بيانات عضو"""
        try:
            conn = self.get_connection()
            if not conn:
                return False
            
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE members 
                SET affiliation = %s, violations = %s, additional_info = %s, 
                    special_case = %s, updated_at = CURRENT_TIMESTAMP
                WHERE member_id = %s
            """, (
                update_data.get("affiliation"),
                update_data.get("violations", "لا يوجد"),
                update_data.get("additional_info", ""),
                update_data.get("special_case", False),
                member_id
            ))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            # إنشاء نسخة احتياطية تلقائية
            self.create_backup("auto_after_update")
            
            return True
            
        except Exception as e:
            print(f"خطأ في تحديث العضو: {e}")
            return False
    
    def delete_member(self, member_id: str) -> bool:
        """حذف عضو"""
        try:
            conn = self.get_connection()
            if not conn:
                return False
            
            cursor = conn.cursor()
            
            cursor.execute("DELETE FROM members WHERE member_id = %s", (member_id,))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            # إنشاء نسخة احتياطية تلقائية
            self.create_backup("auto_after_delete")
            
            return True
            
        except Exception as e:
            print(f"خطأ في حذف العضو: {e}")
            return False
    
    def get_members_count(self) -> int:
        """الحصول على عدد الأعضاء"""
        try:
            conn = self.get_connection()
            if not conn:
                return 0
            
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM members")
            count = cursor.fetchone()[0]
            
            cursor.close()
            conn.close()
            
            return count
            
        except Exception as e:
            print(f"خطأ في حساب الأعضاء: {e}")
            return 0
    
    def get_stats(self) -> Dict[str, Any]:
        """الحصول على إحصائيات الأعضاء"""
        try:
            members = self.load_members()
            
            # حساب الإحصائيات
            total_members = len(members)
            special_cases = sum(1 for member in members if member.get("specialCase", False))
            
            # حساب الانتماءات
            affiliations = {}
            for member in members:
                affiliation = member.get("affiliation", "غير محدد")
                affiliations[affiliation] = affiliations.get(affiliation, 0) + 1
            
            return {
                "total_members": total_members,
                "special_cases": special_cases,
                "affiliations": affiliations,
                "last_updated": datetime.now().isoformat()
            }
            
        except Exception as e:
            print(f"خطأ في حساب الإحصائيات: {e}")
            return {
                "total_members": 0,
                "special_cases": 0,
                "affiliations": {},
                "last_updated": datetime.now().isoformat()
            }
    
    def create_backup(self, backup_type: str = "manual") -> Tuple[bool, str]:
        """إنشاء نسخة احتياطية"""
        try:
            members = self.load_members()
            timestamp = datetime.now().isoformat()
            
            backup_data = {
                "members": members,
                "timestamp": timestamp,
                "backup_type": backup_type,
                "total_members": len(members)
            }
            
            conn = self.get_connection()
            if not conn:
                return False, ""
            
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO backups (backup_data, backup_type)
                VALUES (%s, %s)
            """, (json.dumps(backup_data), backup_type))
            
            conn.commit()
            cursor.close()
            conn.close()
            
            return True, timestamp
            
        except Exception as e:
            print(f"خطأ في إنشاء النسخة الاحتياطية: {e}")
            return False, ""
    
    def force_backup(self) -> Tuple[bool, str]:
        """إنشاء نسخة احتياطية قسرية"""
        return self.create_backup("force_manual")

# إنشاء مثيل عام للاستخدام
postgres_storage = PostgreSQLStorage()

