from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Member(db.Model):
    __tablename__ = 'members'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.String(50), unique=True, nullable=False)
    affiliation = db.Column(db.String(100), nullable=False)
    violations = db.Column(db.String(200), nullable=False)
    additional_info = db.Column(db.Text, nullable=True)
    special_case = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    def to_dict(self):
        return {
            'id': self.id,
            'memberId': self.member_id,
            'affiliation': self.affiliation,
            'violations': self.violations,
            'additionalInfo': self.additional_info,
            'specialCase': self.special_case,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
            'updatedAt': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @staticmethod
    def from_dict(data):
        return Member(
            member_id=data.get('memberId'),
            affiliation=data.get('affiliation'),
            violations=data.get('violations'),
            additional_info=data.get('additionalInfo'),
            special_case=data.get('specialCase', False)
        )

