import json
import os
import shutil
from datetime import datetime
import threading
import time

class PersistentStorage:
    """نظام تخزين دائم محسن للبيانات باستخدام ملفات JSON مع نسخ احتياطية"""
    
    def __init__(self, storage_dir="data"):
        self.storage_dir = storage_dir
        self.members_file = os.path.join(storage_dir, "members.json")
        self.backup_dir = os.path.join(storage_dir, "backups")
        self.lock = threading.Lock()  # لضمان الأمان في العمليات المتزامنة
        self.ensure_storage_dir()
        self.load_initial_data()
        self.start_auto_backup()
    
    def ensure_storage_dir(self):
        """إنشاء مجلدات التخزين إذا لم تكن موجودة"""
        for directory in [self.storage_dir, self.backup_dir]:
            if not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
    
    def create_backup(self):
        """إنشاء نسخة احتياطية من البيانات"""
        try:
            if os.path.exists(self.members_file):
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_file = os.path.join(self.backup_dir, f"members_backup_{timestamp}.json")
                shutil.copy2(self.members_file, backup_file)
                
                # الاحتفاظ بآخر 10 نسخ احتياطية فقط
                backup_files = sorted([f for f in os.listdir(self.backup_dir) if f.startswith("members_backup_")])
                if len(backup_files) > 10:
                    for old_backup in backup_files[:-10]:
                        os.remove(os.path.join(self.backup_dir, old_backup))
        except Exception as e:
            print(f"خطأ في إنشاء النسخة الاحتياطية: {e}")
    
    def start_auto_backup(self):
        """بدء النسخ الاحتياطي التلقائي كل 30 دقيقة"""
        def backup_worker():
            while True:
                time.sleep(1800)  # 30 دقيقة
                self.create_backup()
        
        backup_thread = threading.Thread(target=backup_worker, daemon=True)
        backup_thread.start()
    
    def load_initial_data(self):
        """تحميل البيانات الأولية إذا لم يكن الملف موجوداً"""
        if not os.path.exists(self.members_file):
            initial_data = [
                {
                    "id": 1,
                    "memberId": "M001",
                    "affiliation": "هاديس 🩸",
                    "violations": "6س",
                    "additionalInfo": "عضو نشط في المجموعة",
                    "specialCase": False,
                    "createdAt": datetime.now().isoformat(),
                    "updatedAt": datetime.now().isoformat()
                },
                {
                    "id": 2,
                    "memberId": "M002",
                    "affiliation": "الجليد ❄️",
                    "violations": "12س",
                    "additionalInfo": "مشرف مساعد",
                    "specialCase": True,
                    "createdAt": datetime.now().isoformat(),
                    "updatedAt": datetime.now().isoformat()
                },
                {
                    "id": 3,
                    "memberId": "M003",
                    "affiliation": "الطبيعة 🌿",
                    "violations": "1ي",
                    "additionalInfo": "",
                    "specialCase": False,
                    "createdAt": datetime.now().isoformat(),
                    "updatedAt": datetime.now().isoformat()
                }
            ]
            self.save_members(initial_data)
    
    def load_members(self):
        """تحميل جميع الأعضاء من الملف مع الحماية من الأخطاء"""
        with self.lock:
            try:
                if os.path.exists(self.members_file):
                    with open(self.members_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        return data if isinstance(data, list) else []
                return []
            except (FileNotFoundError, json.JSONDecodeError, Exception) as e:
                print(f"خطأ في تحميل البيانات: {e}")
                # محاولة استرداد من النسخة الاحتياطية
                return self.restore_from_backup()
    
    def restore_from_backup(self):
        """استرداد البيانات من النسخة الاحتياطية الأحدث"""
        try:
            if os.path.exists(self.backup_dir):
                backup_files = sorted([f for f in os.listdir(self.backup_dir) if f.startswith("members_backup_")])
                if backup_files:
                    latest_backup = os.path.join(self.backup_dir, backup_files[-1])
                    with open(latest_backup, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        # نسخ البيانات المسترجعة إلى الملف الأساسي
                        self.save_members(data)
                        return data
        except Exception as e:
            print(f"خطأ في استرداد النسخة الاحتياطية: {e}")
        
        return []
    
    def save_members(self, members):
        """حفظ جميع الأعضاء في الملف مع الحماية والنسخ الاحتياطي"""
        with self.lock:
            try:
                # إنشاء نسخة احتياطية قبل الحفظ
                self.create_backup()
                
                # كتابة البيانات إلى ملف مؤقت أولاً
                temp_file = self.members_file + ".tmp"
                with open(temp_file, 'w', encoding='utf-8') as f:
                    json.dump(members, f, ensure_ascii=False, indent=2)
                
                # نقل الملف المؤقت إلى الملف الأساسي (عملية ذرية)
                if os.name == 'nt':  # Windows
                    if os.path.exists(self.members_file):
                        os.remove(self.members_file)
                    os.rename(temp_file, self.members_file)
                else:  # Unix/Linux
                    os.rename(temp_file, self.members_file)
                
                # التأكد من صحة الملف المحفوظ
                with open(self.members_file, 'r', encoding='utf-8') as f:
                    json.load(f)  # اختبار قراءة الملف
                    
            except Exception as e:
                print(f"خطأ في حفظ البيانات: {e}")
                # حذف الملف المؤقت في حالة الخطأ
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                raise
    
    def add_member(self, member_data):
        """إضافة عضو جديد مع التحقق والحفظ الآمن"""
        members = self.load_members()
        
        # التحقق من عدم وجود رقم العضو مسبقاً
        for member in members:
            if member.get("memberId") == member_data.get("memberId"):
                raise ValueError("رقم العضو موجود مسبقاً")
        
        # إنشاء ID جديد
        new_id = max([m.get("id", 0) for m in members], default=0) + 1
        
        new_member = {
            "id": new_id,
            "memberId": member_data.get("memberId"),
            "affiliation": member_data.get("affiliation"),
            "violations": member_data.get("violations"),
            "additionalInfo": member_data.get("additionalInfo", ""),
            "specialCase": member_data.get("specialCase", False),
            "createdAt": datetime.now().isoformat(),
            "updatedAt": datetime.now().isoformat()
        }
        
        members.append(new_member)
        self.save_members(members)
        return new_member
    
    def update_member(self, member_id, member_data):
        """تحديث عضو موجود مع الحفظ الآمن"""
        members = self.load_members()
        
        for i, member in enumerate(members):
            if member.get("id") == member_id:
                members[i].update({
                    "memberId": member_data.get("memberId", member.get("memberId")),
                    "affiliation": member_data.get("affiliation", member.get("affiliation")),
                    "violations": member_data.get("violations", member.get("violations")),
                    "additionalInfo": member_data.get("additionalInfo", member.get("additionalInfo")),
                    "specialCase": member_data.get("specialCase", member.get("specialCase")),
                    "updatedAt": datetime.now().isoformat()
                })
                self.save_members(members)
                return members[i]
        
        raise ValueError("العضو غير موجود")
    
    def delete_member(self, member_id):
        """حذف عضو مع الحفظ الآمن"""
        members = self.load_members()
        
        for i, member in enumerate(members):
            if member.get("id") == member_id:
                deleted_member = members.pop(i)
                self.save_members(members)
                return deleted_member
        
        raise ValueError("العضو غير موجود")
    
    def get_member_by_id(self, member_id):
        """الحصول على عضو بواسطة ID"""
        members = self.load_members()
        
        for member in members:
            if member.get("id") == member_id:
                return member
        
        return None
    
    def search_members(self, search_term="", search_type="general"):
        """البحث في الأعضاء"""
        members = self.load_members()
        
        if search_term:
            filtered_members = []
            for member in members:
                if (search_term.lower() in member.get("memberId", "").lower() or 
                    search_term.lower() in member.get("affiliation", "").lower()):
                    filtered_members.append(member)
            members = filtered_members
        
        if search_type == "supervisor":
            members = [m for m in members if m.get("specialCase", False)]
        elif search_type == "violation":
            members = [m for m in members if ("زرف" in m.get("violations", "") or m.get("specialCase", False))]
        
        return members
    
    def get_stats(self):
        """الحصول على إحصائيات الانتماءات"""
        members = self.load_members()
        stats = {}
        
        for member in members:
            affiliation = member.get("affiliation", "")
            if affiliation in stats:
                stats[affiliation] += 1
            else:
                stats[affiliation] = 1
        
        # تحويل إلى التنسيق المطلوب للواجهة الأمامية
        result = []
        emoji_colors = {
            "🎻": "#8B0000",
            "🧭": "#00008B", 
            "🏹": "#006400",
            "🎐": "#4B0082",
            "🐦‍🔥": "#FFD700",
            "🩸": "#FF4500",
            "🪻": "#8A2BE2",
            "🎲": "#008000",
            "🃏": "#DC143C",
            "🍷": "#800000",
            "🛡": "#4682B4",
        }
        
        for affiliation, count in stats.items():
            # استخراج الإيموجي من النص
            extracted_emoji = ""
            extracted_name = affiliation
            for emoji_char in emoji_colors.keys():
                if emoji_char in affiliation:
                    extracted_emoji = emoji_char
                    extracted_name = affiliation.replace(emoji_char, "").strip()
                    break
            
            result.append({
                "emoji": extracted_emoji,
                "name": extracted_name,
                "count": count,
                "color": emoji_colors.get(extracted_emoji, "#666666")
            })
        
        return result
    
    def get_backup_info(self):
        """الحصول على معلومات النسخ الاحتياطية"""
        try:
            if os.path.exists(self.backup_dir):
                backup_files = [f for f in os.listdir(self.backup_dir) if f.startswith("members_backup_")]
                return {
                    "backup_count": len(backup_files),
                    "latest_backup": max(backup_files) if backup_files else None,
                    "storage_healthy": os.path.exists(self.members_file)
                }
        except Exception:
            pass
        
        return {
            "backup_count": 0,
            "latest_backup": None,
            "storage_healthy": False
        }

# إنشاء مثيل عام للاستخدام
storage = PersistentStorage()

