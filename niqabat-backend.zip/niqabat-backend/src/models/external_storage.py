import json
import requests
from datetime import datetime
import os

class ExternalStorage:
    """نظام تخزين خارجي يستخدم خدمة JSON Bin لضمان الحفظ الدائم"""
    
    def __init__(self):
        # استخدام JSONBin.io كخدمة تخزين خارجية مجانية
        self.api_url = "https://api.jsonbin.io/v3/b"
        self.bin_id = "676e8a2fad19ca34f8c8e5a2"  # معرف فريد للمشروع
        self.headers = {
            "Content-Type": "application/json",
            "X-Master-Key": "$2a$10$YourAPIKeyHere",  # مفتاح API (يمكن تركه فارغ للاختبار)
        }
        self.fallback_file = "data/members_external.json"
        self.ensure_fallback_dir()
        
    def ensure_fallback_dir(self):
        """إنشاء مجلد النسخة الاحتياطية المحلية"""
        os.makedirs(os.path.dirname(self.fallback_file), exist_ok=True)
    
    def load_members(self):
        """تحميل الأعضاء من الخدمة الخارجية مع fallback محلي"""
        try:
            # محاولة التحميل من الخدمة الخارجية
            response = requests.get(f"{self.api_url}/{self.bin_id}/latest", 
                                  headers=self.headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                members = data.get("record", [])
                # حفظ نسخة محلية احتياطية
                self.save_fallback(members)
                return members
        except Exception as e:
            print(f"خطأ في التحميل من الخدمة الخارجية: {e}")
        
        # في حالة فشل التحميل، استخدام النسخة المحلية
        return self.load_fallback()
    
    def save_members(self, members):
        """حفظ الأعضاء في الخدمة الخارجية مع نسخة احتياطية محلية"""
        success = False
        
        try:
            # محاولة الحفظ في الخدمة الخارجية
            payload = {
                "members": members,
                "last_updated": datetime.now().isoformat(),
                "version": "2.0"
            }
            
            response = requests.put(f"{self.api_url}/{self.bin_id}", 
                                  json=payload, headers=self.headers, timeout=10)
            if response.status_code == 200:
                success = True
                print("تم حفظ البيانات في الخدمة الخارجية بنجاح")
        except Exception as e:
            print(f"خطأ في الحفظ في الخدمة الخارجية: {e}")
        
        # حفظ نسخة محلية في جميع الأحوال
        self.save_fallback(members)
        
        return success
    
    def save_fallback(self, members):
        """حفظ نسخة احتياطية محلية"""
        try:
            with open(self.fallback_file, 'w', encoding='utf-8') as f:
                json.dump(members, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"خطأ في حفظ النسخة المحلية: {e}")
    
    def load_fallback(self):
        """تحميل النسخة الاحتياطية المحلية"""
        try:
            if os.path.exists(self.fallback_file):
                with open(self.fallback_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"خطأ في تحميل النسخة المحلية: {e}")
        
        # إرجاع بيانات أولية في حالة عدم وجود أي بيانات
        return [
            {
                "id": 1,
                "memberId": "M001",
                "affiliation": "هاديس 🩸",
                "violations": "6س",
                "additionalInfo": "عضو نشط في المجموعة",
                "specialCase": False,
                "createdAt": datetime.now().isoformat(),
                "updatedAt": datetime.now().isoformat()
            },
            {
                "id": 2,
                "memberId": "M002",
                "affiliation": "الجليد ❄️",
                "violations": "12س",
                "additionalInfo": "مشرف مساعد",
                "specialCase": True,
                "createdAt": datetime.now().isoformat(),
                "updatedAt": datetime.now().isoformat()
            },
            {
                "id": 3,
                "memberId": "M003",
                "affiliation": "الطبيعة 🌿",
                "violations": "1ي",
                "additionalInfo": "",
                "specialCase": False,
                "createdAt": datetime.now().isoformat(),
                "updatedAt": datetime.now().isoformat()
            }
        ]

# نظام تخزين هجين يجمع بين التخزين المحلي والخارجي
class HybridStorage:
    """نظام تخزين هجين يستخدم عدة طرق لضمان الحفظ الدائم"""
    
    def __init__(self):
        self.local_file = "data/members_hybrid.json"
        self.ensure_data_dir()
        self.load_initial_data()
    
    def ensure_data_dir(self):
        """إنشاء مجلد البيانات"""
        os.makedirs(os.path.dirname(self.local_file), exist_ok=True)
    
    def load_initial_data(self):
        """تحميل البيانات الأولية"""
        if not os.path.exists(self.local_file):
            initial_data = [
                {
                    "id": 1,
                    "memberId": "M001",
                    "affiliation": "هاديس 🩸",
                    "violations": "6س",
                    "additionalInfo": "عضو نشط في المجموعة",
                    "specialCase": False,
                    "createdAt": datetime.now().isoformat(),
                    "updatedAt": datetime.now().isoformat()
                },
                {
                    "id": 2,
                    "memberId": "M002",
                    "affiliation": "الجليد ❄️",
                    "violations": "12س",
                    "additionalInfo": "مشرف مساعد",
                    "specialCase": True,
                    "createdAt": datetime.now().isoformat(),
                    "updatedAt": datetime.now().isoformat()
                },
                {
                    "id": 3,
                    "memberId": "M003",
                    "affiliation": "الطبيعة 🌿",
                    "violations": "1ي",
                    "additionalInfo": "",
                    "specialCase": False,
                    "createdAt": datetime.now().isoformat(),
                    "updatedAt": datetime.now().isoformat()
                }
            ]
            self.save_members(initial_data)
    
    def load_members(self):
        """تحميل الأعضاء مع معالجة الأخطاء المحسنة"""
        try:
            if os.path.exists(self.local_file):
                with open(self.local_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data if isinstance(data, list) else []
        except Exception as e:
            print(f"خطأ في تحميل البيانات: {e}")
        
        return []
    
    def save_members(self, members):
        """حفظ الأعضاء مع ضمانات إضافية للحفظ الدائم"""
        try:
            # حفظ في ملف مؤقت أولاً
            temp_file = self.local_file + ".tmp"
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(members, f, ensure_ascii=False, indent=2)
            
            # نقل الملف المؤقت إلى الملف الأساسي
            if os.name == 'nt':  # Windows
                if os.path.exists(self.local_file):
                    os.remove(self.local_file)
                os.rename(temp_file, self.local_file)
            else:  # Unix/Linux
                os.rename(temp_file, self.local_file)
            
            # إنشاء نسخ إضافية للأمان
            backup_files = [
                self.local_file + ".backup1",
                self.local_file + ".backup2",
                self.local_file + ".backup3"
            ]
            
            for backup_file in backup_files:
                try:
                    with open(backup_file, 'w', encoding='utf-8') as f:
                        json.dump(members, f, ensure_ascii=False, indent=2)
                except:
                    pass  # تجاهل أخطاء النسخ الاحتياطية
            
            return True
            
        except Exception as e:
            print(f"خطأ في حفظ البيانات: {e}")
            return False
    
    def add_member(self, member_data):
        """إضافة عضو جديد"""
        members = self.load_members()
        
        # التحقق من عدم وجود رقم العضو مسبقاً
        for member in members:
            if member.get("memberId") == member_data.get("memberId"):
                raise ValueError("رقم العضو موجود مسبقاً")
        
        # إنشاء ID جديد
        new_id = max([m.get("id", 0) for m in members], default=0) + 1
        
        new_member = {
            "id": new_id,
            "memberId": member_data.get("memberId"),
            "affiliation": member_data.get("affiliation"),
            "violations": member_data.get("violations"),
            "additionalInfo": member_data.get("additionalInfo", ""),
            "specialCase": member_data.get("specialCase", False),
            "createdAt": datetime.now().isoformat(),
            "updatedAt": datetime.now().isoformat()
        }
        
        members.append(new_member)
        self.save_members(members)
        return new_member
    
    def update_member(self, member_id, member_data):
        """تحديث عضو موجود"""
        members = self.load_members()
        
        for i, member in enumerate(members):
            if member.get("id") == member_id:
                members[i].update({
                    "memberId": member_data.get("memberId", member.get("memberId")),
                    "affiliation": member_data.get("affiliation", member.get("affiliation")),
                    "violations": member_data.get("violations", member.get("violations")),
                    "additionalInfo": member_data.get("additionalInfo", member.get("additionalInfo")),
                    "specialCase": member_data.get("specialCase", member.get("specialCase")),
                    "updatedAt": datetime.now().isoformat()
                })
                self.save_members(members)
                return members[i]
        
        raise ValueError("العضو غير موجود")
    
    def delete_member(self, member_id):
        """حذف عضو"""
        members = self.load_members()
        
        for i, member in enumerate(members):
            if member.get("id") == member_id:
                deleted_member = members.pop(i)
                self.save_members(members)
                return deleted_member
        
        raise ValueError("العضو غير موجود")
    
    def get_member_by_id(self, member_id):
        """الحصول على عضو بواسطة ID"""
        members = self.load_members()
        
        for member in members:
            if member.get("id") == member_id:
                return member
        
        return None
    
    def search_members(self, search_term="", search_type="general"):
        """البحث في الأعضاء"""
        members = self.load_members()
        
        if search_term:
            filtered_members = []
            for member in members:
                if (search_term.lower() in member.get("memberId", "").lower() or 
                    search_term.lower() in member.get("affiliation", "").lower()):
                    filtered_members.append(member)
            members = filtered_members
        
        if search_type == "supervisor":
            members = [m for m in members if m.get("specialCase", False)]
        elif search_type == "violation":
            members = [m for m in members if ("زرف" in m.get("violations", "") or m.get("specialCase", False))]
        
        return members
    
    def get_stats(self):
        """الحصول على إحصائيات الانتماءات"""
        members = self.load_members()
        stats = {}
        
        for member in members:
            affiliation = member.get("affiliation", "")
            if affiliation in stats:
                stats[affiliation] += 1
            else:
                stats[affiliation] = 1
        
        # تحويل إلى التنسيق المطلوب للواجهة الأمامية
        result = []
        emoji_colors = {
            "🎻": "#8B0000",
            "🧭": "#00008B", 
            "🏹": "#006400",
            "🎐": "#4B0082",
            "🐦‍🔥": "#FFD700",
            "🩸": "#FF4500",
            "🪻": "#8A2BE2",
            "🎲": "#008000",
            "🃏": "#DC143C",
            "🍷": "#800000",
            "🛡": "#4682B4",
        }
        
        for affiliation, count in stats.items():
            # استخراج الإيموجي من النص
            extracted_emoji = ""
            extracted_name = affiliation
            for emoji_char in emoji_colors.keys():
                if emoji_char in affiliation:
                    extracted_emoji = emoji_char
                    extracted_name = affiliation.replace(emoji_char, "").strip()
                    break
            
            result.append({
                "emoji": extracted_emoji,
                "name": extracted_name,
                "count": count,
                "color": emoji_colors.get(extracted_emoji, "#666666")
            })
        
        return result

# إنشاء مثيل للاستخدام
hybrid_storage = HybridStorage()

