from flask import Blueprint, request, jsonify
from src.models.postgres_storage import postgres_storage

member_bp = Blueprint("member", __name__)

@member_bp.route("/members", methods=["GET"])
def get_members():
    """Get all members with optional search and filtering"""
    try:
        search_term = request.args.get("search", "")
        search_type = request.args.get("type", "general")  # general, supervisor, violation
        
        members = postgres_storage.load_members()
        
        if search_term:
            # البحث عن الأعضاء
            results = []
            
            for member in members:
                # البحث في رقم العضو والانتماء والمعلومات الإضافية
                if (search_term.lower() in member.get("memberId", "").lower() or
                    search_term.lower() in member.get("affiliation", "").lower() or
                    search_term.lower() in member.get("additionalInfo", "").lower()):
                    
                    # تطبيق فلتر نوع البحث
                    if search_type == "special" and not member.get("specialCase", False):
                        continue
                    elif search_type == "violations" and member.get("violations", "لا يوجد") == "لا يوجد":
                        continue
                    
                    results.append(member)
            
            return jsonify({"success": True, "members": results})
        else:
            return jsonify({"success": True, "members": members})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@member_bp.route("/members", methods=["POST"])
def create_member():
    """Create a new member"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        required_fields = ["memberId", "affiliation"]
        for field in required_fields:
            if field not in data:
                return jsonify({"success": False, "error": f"الحقل {field} مطلوب"}), 400
        
        # إعداد البيانات الافتراضية
        member_data = {
            "member_id": data["memberId"],
            "affiliation": data["affiliation"],
            "violations": data.get("violations", "لا يوجد"),
            "additional_info": data.get("additionalInfo", ""),
            "special_case": data.get("specialCase", False)
        }
        
        success = postgres_storage.add_member(member_data)
        
        if success:
            return jsonify({"success": True, "message": "تم إضافة العضو بنجاح"}), 201
        else:
            return jsonify({"success": False, "error": "فشل في إضافة العضو"}), 500
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@member_bp.route("/members/<member_id>", methods=["PUT"])
def update_member(member_id):
    """Update an existing member"""
    try:
        data = request.get_json()
        
        # إعداد البيانات للتحديث
        update_data = {
            "affiliation": data.get("affiliation"),
            "violations": data.get("violations", "لا يوجد"),
            "additional_info": data.get("additionalInfo", ""),
            "special_case": data.get("specialCase", False)
        }
        
        success = postgres_storage.update_member(member_id, update_data)
        
        if success:
            return jsonify({"success": True, "message": "تم تحديث العضو بنجاح"})
        else:
            return jsonify({"success": False, "error": "فشل في تحديث العضو"}), 500
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@member_bp.route("/members/<member_id>", methods=["DELETE"])
def delete_member(member_id):
    """Delete a member"""
    try:
        success = postgres_storage.delete_member(member_id)
        
        if success:
            return jsonify({"success": True, "message": "تم حذف العضو بنجاح"})
        else:
            return jsonify({"success": False, "error": "فشل في حذف العضو"}), 500
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@member_bp.route("/members/stats", methods=["GET"])
def get_member_stats():
    """Get statistics for the public page"""
    try:
        stats = postgres_storage.get_stats()
        return jsonify({"success": True, "stats": stats})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


