from flask import Blueprint, request, jsonify

auth_bp = Blueprint('auth', __name__)

# Password configuration
SUPER_ADMIN_PASSWORD = 'Rn12345678'
LIMITED_ADMIN_PASSWORD = 'rio87654321'

@auth_bp.route('/auth/login', methods=['POST'])
def login():
    """Authenticate user with password"""
    try:
        data = request.get_json()
        password = data.get('password', '')
        
        if password == SUPER_ADMIN_PASSWORD:
            return jsonify({
                'success': True,
                'role': 'super',
                'message': 'تم تسجيل الدخول بنجاح كمسؤول أعلى'
            })
        elif password == LIMITED_ADMIN_PASSWORD:
            return jsonify({
                'success': True,
                'role': 'limited',
                'message': 'تم تسجيل الدخول بنجاح كمشرف محدود'
            })
        else:
            return jsonify({
                'success': False,
                'message': 'كلمة مرور خاطئة'
            }), 401
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/auth/validate', methods=['POST'])
def validate_role():
    """Validate user role for specific actions"""
    try:
        data = request.get_json()
        password = data.get('password', '')
        action = data.get('action', '')  # 'create', 'update', 'delete', 'report'
        
        if password == SUPER_ADMIN_PASSWORD:
            return jsonify({'authorized': True, 'role': 'super'})
        elif password == LIMITED_ADMIN_PASSWORD:
            # Limited admin can only view, not modify
            if action in ['view', 'search']:
                return jsonify({'authorized': True, 'role': 'limited'})
            else:
                return jsonify({'authorized': False, 'message': 'ليس لديك صلاحية لهذا الإجراء'}), 403
        else:
            return jsonify({'authorized': False, 'message': 'كلمة مرور خاطئة'}), 401
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

