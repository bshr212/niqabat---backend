from flask import Blueprint, jsonify
from src.models.postgres_storage import postgres_storage

save_bp = Blueprint("save", __name__)

@save_bp.route("/save/force", methods=["POST"])
def force_save():
    """حفظ قسري لجميع التعديلات"""
    try:
        # إنشاء نسخة احتياطية قسرية
        success, timestamp = postgres_storage.force_backup()
        
        if success:
            # الحصول على إحصائيات محدثة
            stats = postgres_storage.get_stats()
            
            return jsonify({
                "success": True,
                "message": "تم حفظ جميع التعديلات بنجاح في قاعدة البيانات",
                "timestamp": timestamp,
                "members_count": stats.get("total_members", 0),
                "backup_created": True,
                "verification_count": stats.get("total_members", 0),
                "database_type": "PostgreSQL"
            })
        else:
            return jsonify({
                "success": False,
                "error": "فشل في إنشاء النسخة الاحتياطية"
            }), 500
            
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"خطأ في عملية الحفظ: {str(e)}"
        }), 500

