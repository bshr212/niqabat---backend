from flask import Blueprint, request, jsonify, send_file
from src.models.member import db, Member
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import inch
import os
import tempfile
from datetime import datetime

report_bp = Blueprint('report', __name__)

@report_bp.route('/reports/pdf', methods=['POST'])
def generate_pdf_report():
    """Generate PDF report for all members grouped by affiliation"""
    try:
        # Get all members from database
        members = Member.query.all()
        
        if not members:
            return jsonify({'error': 'لا توجد بيانات لإنشاء التقرير'}), 400
        
        # Group members by affiliation
        affiliations = {}
        for member in members:
            affiliation = member.affiliation
            if affiliation not in affiliations:
                affiliations[affiliation] = []
            affiliations[affiliation].append(member)
        
        # Create temporary file for PDF
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
        temp_file.close()
        
        # Create PDF document
        doc = SimpleDocTemplate(temp_file.name, pagesize=A4)
        story = []
        
        # Get styles
        styles = getSampleStyleSheet()
        
        # Create custom styles for Arabic text
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=1,  # Center alignment
        )
        
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            alignment=2,  # Right alignment for Arabic
        )
        
        normal_style = ParagraphStyle(
            'CustomNormal',
            parent=styles['Normal'],
            fontSize=10,
            alignment=2,  # Right alignment for Arabic
        )
        
        # Add title
        title = Paragraph("تقرير أعضاء النقابات", title_style)
        story.append(title)
        story.append(Spacer(1, 20))
        
        # Add generation date
        date_text = f"تاريخ إنشاء التقرير: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        date_para = Paragraph(date_text, normal_style)
        story.append(date_para)
        story.append(Spacer(1, 20))
        
        # Add summary statistics
        total_members = len(members)
        total_affiliations = len(affiliations)
        summary_text = f"إجمالي الأعضاء: {total_members} | إجمالي الانتماءات: {total_affiliations}"
        summary_para = Paragraph(summary_text, heading_style)
        story.append(summary_para)
        story.append(Spacer(1, 20))
        
        # Add members by affiliation
        for affiliation, affiliation_members in affiliations.items():
            # Affiliation header
            affiliation_header = Paragraph(f"انتماء: {affiliation} ({len(affiliation_members)} أعضاء)", heading_style)
            story.append(affiliation_header)
            story.append(Spacer(1, 10))
            
            # Create table data
            table_data = [
                ['معلومات إضافية', 'حالة خاصة', 'المخالفات', 'رقم العضو']
            ]
            
            for member in affiliation_members:
                table_data.append([
                    member.additional_info or '-',
                    'نعم' if member.special_case else 'لا',
                    member.violations,
                    member.member_id
                ])
            
            # Create table
            table = Table(table_data, colWidths=[2*inch, 1*inch, 1*inch, 1*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(table)
            story.append(Spacer(1, 20))
        
        # Build PDF
        doc.build(story)
        
        # Return PDF file
        return send_file(
            temp_file.name,
            as_attachment=True,
            download_name=f'niqabat_report_{datetime.now().strftime("%Y%m%d_%H%M")}.pdf',
            mimetype='application/pdf'
        )
        
    except Exception as e:
        return jsonify({'error': f'حدث خطأ في إنشاء التقرير: {str(e)}'}), 500

@report_bp.route('/reports/stats', methods=['GET'])
def get_detailed_stats():
    """Get detailed statistics for reporting"""
    try:
        members = Member.query.all()
        
        # Group by affiliation
        affiliations = {}
        special_cases = 0
        violation_types = {}
        
        for member in members:
            affiliation = member.affiliation
            if affiliation not in affiliations:
                affiliations[affiliation] = {
                    'count': 0,
                    'special_cases': 0,
                    'violations': []
                }
            
            affiliations[affiliation]['count'] += 1
            affiliations[affiliation]['violations'].append(member.violations)
            
            if member.special_case:
                special_cases += 1
                affiliations[affiliation]['special_cases'] += 1
            
            # Count violation types
            violation = member.violations
            if violation in violation_types:
                violation_types[violation] += 1
            else:
                violation_types[violation] = 1
        
        return jsonify({
            'total_members': len(members),
            'total_affiliations': len(affiliations),
            'special_cases': special_cases,
            'affiliations': affiliations,
            'violation_types': violation_types
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

