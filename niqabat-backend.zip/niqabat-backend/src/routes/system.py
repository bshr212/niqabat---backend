from flask import Blueprint, jsonify
from src.models.persistent_storage import storage
import os
from datetime import datetime

system_bp = Blueprint("system", __name__)

@system_bp.route("/health", methods=["GET"])
def health_check():
    """فحص حالة النظام"""
    try:
        # اختبار قراءة البيانات
        members = storage.load_members()
        backup_info = storage.get_backup_info()
        
        return jsonify({
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "members_count": len(members),
            "storage_healthy": backup_info["storage_healthy"],
            "backup_count": backup_info["backup_count"],
            "latest_backup": backup_info["latest_backup"]
        }), 200
    except Exception as e:
        return jsonify({
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }), 500

@system_bp.route("/backup/create", methods=["POST"])
def create_manual_backup():
    """إنشاء نسخة احتياطية يدوية"""
    try:
        storage.create_backup()
        backup_info = storage.get_backup_info()
        
        return jsonify({
            "message": "تم إنشاء النسخة الاحتياطية بنجاح",
            "backup_count": backup_info["backup_count"],
            "latest_backup": backup_info["latest_backup"]
        }), 200
    except Exception as e:
        return jsonify({
            "error": f"فشل في إنشاء النسخة الاحتياطية: {str(e)}"
        }), 500

@system_bp.route("/backup/info", methods=["GET"])
def get_backup_info():
    """الحصول على معلومات النسخ الاحتياطية"""
    try:
        backup_info = storage.get_backup_info()
        return jsonify(backup_info), 200
    except Exception as e:
        return jsonify({
            "error": f"فشل في الحصول على معلومات النسخ الاحتياطية: {str(e)}"
        }), 500

@system_bp.route("/storage/verify", methods=["GET"])
def verify_storage():
    """التحقق من سلامة نظام التخزين"""
    try:
        # اختبار قراءة وكتابة البيانات
        test_member = {
            "memberId": "TEST_VERIFY",
            "affiliation": "اختبار النظام 🔧",
            "violations": "لا يوجد",
            "additionalInfo": "عضو اختبار للتحقق من النظام",
            "specialCase": False
        }
        
        # إضافة عضو اختبار
        added_member = storage.add_member(test_member)
        
        # قراءة العضو المضاف
        retrieved_member = storage.get_member_by_id(added_member["id"])
        
        # حذف عضو الاختبار
        storage.delete_member(added_member["id"])
        
        return jsonify({
            "status": "verified",
            "message": "نظام التخزين يعمل بشكل صحيح",
            "test_completed": True
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "failed",
            "error": f"فشل في التحقق من نظام التخزين: {str(e)}",
            "test_completed": False
        }), 500

@system_bp.route("/stats/detailed", methods=["GET"])
def get_detailed_stats():
    """الحصول على إحصائيات مفصلة للنظام"""
    try:
        members = storage.load_members()
        backup_info = storage.get_backup_info()
        
        # حساب إحصائيات مفصلة
        total_members = len(members)
        special_cases = len([m for m in members if m.get("specialCase", False)])
        affiliations = {}
        
        for member in members:
            affiliation = member.get("affiliation", "غير محدد")
            affiliations[affiliation] = affiliations.get(affiliation, 0) + 1
        
        return jsonify({
            "total_members": total_members,
            "special_cases": special_cases,
            "regular_members": total_members - special_cases,
            "affiliations_count": len(affiliations),
            "affiliations": affiliations,
            "storage_info": {
                "backup_count": backup_info["backup_count"],
                "storage_healthy": backup_info["storage_healthy"],
                "latest_backup": backup_info["latest_backup"]
            },
            "timestamp": datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({
            "error": f"فشل في الحصول على الإحصائيات المفصلة: {str(e)}"
        }), 500

